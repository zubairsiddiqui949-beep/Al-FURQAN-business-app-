1. github.com par free account banayen (Sign up).
2. New repository banayen (naam: alfurqan-app, Public ya Private).
3. "uploading an existing file" par click karen aur is ZIP ke ANDAR ke saare folders/files
   (www, .github, package.json, capacitor.config.json) drag karke upload karen. Commit karen.
   NOTE: .github folder upload hona zaroori hai.
4. Repository me "Actions" tab kholen. "Build APK" chalna shuru ho jayega (3-6 minute).
5. Green tick aane par us run par click karen -> neeche "Artifacts" me AlFurqan-APK download karen.
6. ZIP kholen -> app-debug.apk -> phone me bhejen aur install karen (Unknown sources allow karen).
